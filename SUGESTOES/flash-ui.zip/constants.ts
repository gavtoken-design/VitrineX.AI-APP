
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

export const INITIAL_PLACEHOLDERS = [
    "Crie um cartão de clima minimalista",
    "Mostre um ticker de ações ao vivo",
    "Crie um formulário de login futurista",
    "Construa um dashboard de portfólio",
    "Faça um player de música brutalista",
    "Gere uma tabela de preços elegante",
    "Peça qualquer coisa"
];
