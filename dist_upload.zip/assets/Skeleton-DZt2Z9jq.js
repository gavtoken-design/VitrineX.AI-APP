import{j as a}from"./vendor-DSl67O_0.js";const s=({className:r=""})=>a.jsx("div",{className:`animate-pulse bg-gray-200 dark:bg-gray-800 rounded ${r}`});export{s as S};
