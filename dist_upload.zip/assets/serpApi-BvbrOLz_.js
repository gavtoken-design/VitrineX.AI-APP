import"./index-BN8tTqBV.js";import{G as u}from"./main-C__rKDNJ.js";import{generateText as p}from"./text-mP5O5bYu.js";import"./tools-DCT0r4pr.js";const n="http://localhost:4000/api/trends",g=async(o,r="BR",e="today 1-m")=>{const a=r==="BR"||r==="Brazil"||r==="Brasil"?"BR":"";try{const t=await fetch(`${n}/interest`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({keyword:o,geo:a,timeframe:e})});if(!t.ok)throw new Error(`Trends API status: ${t.status}`);return await t.json()}catch(t){return console.warn("Failed to fetch trends from backend.",t),null}},h=o=>{if(!o)return"";let r=`

[REAL-TIME DATA FROM GOOGLE TRENDS (${o.source||"Unified"})]
`;return o.related_queries?.rising?.length>0&&(r+=`RISING RELATED QUERIES:
`,o.related_queries.rising.slice(0,8).forEach(e=>{r+=`- "${e.query}" (${e.value})
`})),o.related_queries?.top?.length>0&&(r+=`
TOP RELATED QUERIES:
`,o.related_queries.top.slice(0,5).forEach(e=>{r+=`- "${e.query}" (Index: ${e.value})
`})),o.related_topics?.rising?.length>0&&(r+=`
RISING TOPICS:
`,(Array.isArray(o.related_topics.rising)?o.related_topics.rising:[]).slice(0,5).forEach(a=>{const t=a.topic?.title||"Topic";r+=`- ${t} (${a.value})
`})),r},A=async(o="BR")=>{try{const r=await fetch(`${n}/daily?geo=${o}`);if(!r.ok)throw new Error("Daily Trends API Error");const e=await r.json();return Array.isArray(e)?e:[]}catch(r){return console.warn("Failed to fetch daily trends from backend",r),[]}},I=async(o,r,e="Brasil (Nacional)",a="country")=>{const t=new Date().toLocaleDateString("pt-BR",{month:"long",year:"numeric"});let s=`Contexto Geográfico: ${e}.`;(a==="city"||a==="state")&&(s+=` IMPORTANTE: Foque em notícias locais, eventos regionais e economia de ${e}. Busque fontes como jornais locais e portais da região.`);const c=`Atue como uma API de Tendências de Mercado e Inteligência Competitiva de ALTA FIDELIDADE.
    Data de Referência: ${t}.
    O usuário quer saber sobre: "${o}".
    Período de análise: ${r}.
    ${s}

    Pesquise ou use seu conhecimento profundo para gerar um JSON ESTRITAMENTE neste formato:
    {
        "source": "VitrineX Intelligence Layer (${e} - ${t})",
        "interest_over_time": {
            "timeline_data": [
                { "date": "2024-01-01", "values": [{ "value": 45 }] },
                ... gera 15 pontos de dados que reflitam o volume REAL agora em ${t} ...
            ]
        },
        "related_queries": {
            "rising": [
                { "query": "termo específico de ${e}", "value": "Breakout" },
                ...
            ],
            "top": [ ... ]
        },
        "market_context": [
            {
                "title": "Manchete Local/Regional",
                "snippet": "Resumo de 2-3 frases sobre o impacto em ${e}.",
                "impact": "High",
                "source_name": "Nome do Jornal/Portal (Ex: Folha de SP, G1 ${e})",
                "source_url": "https://link-ficticio-para-exemplo.com"
            },
            ... adicione 2 ou 3 contextos locais ...
        ]
    }
    
    IMPORTANTE:
    1. Seja HIPER-REALISTA. Se for uma capital ou estado, cite problemas ou eventos locais reais.
    2. Inclua 'source_url' simulado porém realista (ex: g1.globo.com/${e.toLowerCase().replace(/ /g,"-")}).
    3. Use sua busca interna para ser preciso sobre o que está acontecendo HOJE naquele local.`;try{const l=(await p(c,{model:u,responseMimeType:"application/json",temperature:.4})).replace(/```json/g,"").replace(/```/g,"").trim();return JSON.parse(l)}catch(i){throw console.error("AI Fallback failed:",i),i}};export{h as a,A as b,I as c,g as f};
