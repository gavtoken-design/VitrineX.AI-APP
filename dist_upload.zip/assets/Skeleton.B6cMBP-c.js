import{j as a}from"./vendor-react.CMSr9Sd-.js";const s=({className:s=""})=>a.jsx("div",{className:`animate-pulse bg-gray-200 dark:bg-gray-800 rounded ${s}`});export{s as S};
