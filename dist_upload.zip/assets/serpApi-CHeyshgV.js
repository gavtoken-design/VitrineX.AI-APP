const i="http://localhost:4000/api/trends",a=async(r,e="BR",t="today 1-m")=>{const n=e==="BR"||e==="Brazil"||e==="Brasil"?"BR":"";try{const s=await fetch(`${i}/interest`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({keyword:r,geo:n,timeframe:t})});if(!s.ok)throw new Error(`Trends API status: ${s.status}`);return await s.json()}catch(s){return console.warn("Failed to fetch trends from backend.",s),null}},c=r=>{if(!r)return"";let e=`

[REAL-TIME DATA FROM GOOGLE TRENDS (${r.source||"Unified"})]
`;return r.related_queries?.rising?.length>0&&(e+=`RISING RELATED QUERIES:
`,r.related_queries.rising.slice(0,8).forEach(t=>{e+=`- "${t.query}" (${t.value})
`})),r.related_queries?.top?.length>0&&(e+=`
TOP RELATED QUERIES:
`,r.related_queries.top.slice(0,5).forEach(t=>{e+=`- "${t.query}" (Index: ${t.value})
`})),r.related_topics?.rising?.length>0&&(e+=`
RISING TOPICS:
`,(Array.isArray(r.related_topics.rising)?r.related_topics.rising:[]).slice(0,5).forEach(n=>{const s=n.topic?.title||"Topic";e+=`- ${s} (${n.value})
`})),e},l=async(r="BR")=>{try{const e=await fetch(`${i}/daily?geo=${r}`);if(!e.ok)throw new Error("Daily Trends API Error");const t=await e.json();return Array.isArray(t)?t:[]}catch(e){return console.warn("Failed to fetch daily trends from backend",e),[]}};export{c as a,l as b,a as f};
