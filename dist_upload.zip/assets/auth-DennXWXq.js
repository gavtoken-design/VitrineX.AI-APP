import{w as a}from"./main-JoqQ7vLu.js";const e=async()=>{const{data:{session:t}}=await a.auth.getSession();return t?.access_token||null},n=()=>"default-org";export{e as a,n as g};
