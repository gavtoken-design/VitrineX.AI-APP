import{r as l,z as O,j as e,aG as f,F as v,G as d,O as j,a1 as P,ae as D,R as M,M as k}from"./index-C0yaQWcw.js";import{T as y}from"./Textarea-B3cxqI_X.js";import{I as F}from"./Input-CalDD_v_.js";import"./index-mLFCWBXf.js";import{g as G}from"./text-B_TrvB6e.js";import{H}from"./HowToUse-DMmE-lnD.js";import{F as q}from"./EyeIcon-CoqJ4RDW.js";import"./gemini-Bbk2mklm.js";import"./api-D3NeUaio.js";const K=()=>{const[g,C]=l.useState(""),[u,w]=l.useState(""),[t,x]=l.useState([]),[c,N]=l.useState(""),[o,I]=l.useState(""),[T,h]=l.useState(!1),[m,b]=l.useState(!1),{addToast:i}=O(),p=l.useRef(null),S=s=>{const r=s.target.files;!r||r.length===0||(Array.from(r).forEach(a=>{if(!a.type.startsWith("image/")){i({type:"warning",message:`${a.name} não é uma imagem válida.`});return}const n=new FileReader;n.onloadend=()=>{typeof n.result=="string"&&(x(U=>[...U,{name:a.name,data:n.result}]),i({type:"success",message:`${a.name} adicionada!`}))},n.readAsDataURL(a)}),p.current&&(p.current.value=""))},A=s=>{x(r=>r.filter((a,n)=>n!==s)),i({type:"info",message:"Imagem removida."})},R=async()=>{if(!c.trim()){i({type:"warning",message:"Descreva o tipo de página que deseja criar."});return}const s=`Você é um EXPERT WEB DEVELOPER e DESIGNER premiado (Awwwards level), especializado em criar Landing Pages de Alta Conversão com estética "21.dev" / "Aceternity UI".

## TAREFA
Gere um código HTML/CSS/JS (Single File) completo, deslumbrante e production-ready.

## CONTEÚDO FORNECIDO
${g?`**Texto/Copy:**
${g}
`:""}
${u?`**Imagem URL Externa:**
${u}
`:""}
${t.length>0?`**Imagens Carregadas (${t.length}):**
${t.map((r,a)=>`${a+1}. ${r.name} (Base64 embutida)`).join(`
`)}
`:""}

## TIPO DE PÁGINA SOLICITADA
${c}

## ESTILO VISUAL & UX (Inspired by 21.dev)
- **Aesthetic:** Dark mode default (ou light mode elegante se pedido), gradientes sutis, "glassmorphism", bordas finas com brilho.
- **Animações:** Use CSS animations (@keyframes) para fade-in, slide-up, hover effects ricos, e elementos que reagem ao scroll se possível.
- **Tipografia:** Use fontes modernas do Google Fonts (Inter, Plus Jakarta Sans, Outfit).
- **Layout:** Bento grids, seções de Hero imersivas, cards flutuantes.

## INSTRUÇÕES PARA IMAGENS
${t.length>0?`- Use as ${t.length} imagens fornecidas em base64 (já incluídas no src)
- Distribua as imagens de forma estratégica na página
- Adicione alt text descritivo para cada imagem`:"- Use https://placehold.co/ para placeholders elegantes se necessário"}

## REQUISITOS TÉCNICOS OBRIGATÓRIOS
1. **HTML5 Semântico**
2. **CSS Moderno (Internal <style>)**:
   - Use variáveis CSS (:root) para cores.
   - Flexbox e Grid para layouts complexos.
   - Media queries para responsividade TOTAL (Mobile First).
3. **Conversão**: Botões CTA (Call-to-Action) vibrantes e com efeitos de pulso ou brilho.

## OUTPUT FORMAT
Retorne APENAS o código HTML completo, começando com \`<!DOCTYPE html>\`.
${t.length>0?`IMPORTANTE: Substitua os src das imagens por estas strings base64:
${t.map((r,a)=>`Imagem ${a+1}: src="${r.data.substring(0,50)}..."`).join(`
`)}`:""}
Sem comentários markdown. Apenas o código.`;h(!0);try{let a=(await G(s,{model:M})).trim();a.startsWith("```html")?a=a.replace(/```html\n?/,"").replace(/\n?```$/,""):a.startsWith("```")&&(a=a.replace(/```\n?/,"").replace(/\n?```$/,"")),I(a),b(!0);try{await k({id:`lib-${Date.now()}`,userId:"mock-user-123",name:`HTML - ${s.substring(0,30)}`,file_url:a,type:"text",tags:["code-playground","html","code"],createdAt:new Date().toISOString()})}catch(n){console.warn("Failed to auto-save to library:",n)}i({type:"success",message:"Código HTML gerado com sucesso!"})}catch(r){i({type:"error",message:`Erro ao gerar código: ${r.message}`})}finally{h(!1)}},E=()=>{if(!o)return;const s=new Blob([o],{type:"text/html"}),r=URL.createObjectURL(s),a=document.createElement("a");a.href=r,a.download=`vitrinex-page-${Date.now()}.html`,document.body.appendChild(a),a.click(),document.body.removeChild(a),URL.revokeObjectURL(r),i({type:"success",message:"Código baixado!"})},$=()=>{navigator.clipboard.writeText(o),i({type:"success",message:"Código copiado para a área de transferência!"})},L=()=>{if(!o)return;const s=encodeURIComponent("Página HTML criada com VitrineX AI"),r=encodeURIComponent(`Olá!

Criei esta página HTML usando o VitrineX AI:

${o.substring(0,500)}...

[Código completo anexado]`);window.location.href=`mailto:?subject=${s}&body=${r}`,i({type:"info",message:"Abrindo cliente de email..."})};return e.jsxs("div",{className:"space-y-8 animate-fade-in",children:[e.jsx("div",{className:"flex items-center justify-between pb-6 border-b border-border",children:e.jsxs("div",{className:"flex items-center gap-4",children:[e.jsx("div",{className:"p-3 bg-blue-500/10 rounded-xl",children:e.jsx(f,{className:"w-8 h-8 text-blue-500"})}),e.jsxs("div",{children:[e.jsx("h1",{className:"text-3xl font-bold text-title",children:"Gerador de HTML com IA"}),e.jsx("p",{className:"text-muted",children:"Crie páginas HTML completas com IA"})]})]})}),e.jsx(H,{title:"Como Usar o Code Playground",steps:["Descreva a página HTML que deseja criar","Seja específico sobre layout, cores e funcionalidades","Clique em 'Gerar Código HTML'","Aguarde a geração","Visualize o resultado no preview","Use 'Baixar', 'Copiar' ou 'Enviar' conforme necessário"],tips:["O código é salvo automaticamente na biblioteca","Você pode editar o código manualmente se quiser","Ideal para landing pages, formulários ou protótipos","Use 'Enviar' para compartilhar via email"]}),e.jsxs("div",{className:"grid grid-cols-1 lg:grid-cols-2 gap-6",children:[e.jsxs("div",{className:"space-y-6",children:[e.jsxs("div",{className:"bg-surface p-6 rounded-xl border border-border",children:[e.jsxs("h3",{className:"text-lg font-semibold text-title mb-4 flex items-center gap-2",children:[e.jsx(v,{className:"w-5 h-5 text-blue-500"}),"Conteúdo para a Página"]}),e.jsxs("div",{className:"space-y-4",children:[e.jsx(y,{id:"content-text",label:"Texto/Copy (opcional)",value:g,onChange:s=>C(s.target.value),rows:4,placeholder:"Cole aqui o texto gerado anteriormente (título, descrição, copy, etc.)"}),e.jsx(F,{id:"image-url",label:"URL da Imagem (opcional)",value:u,onChange:s=>w(s.target.value),placeholder:"https://exemplo.com/imagem.jpg"}),e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm font-medium text-title mb-2",children:"Upload de Imagens (múltiplas)"}),e.jsx("input",{ref:p,type:"file",accept:"image/*",multiple:!0,onChange:S,className:"hidden"}),e.jsxs(d,{onClick:()=>{var s;return(s=p.current)==null?void 0:s.click()},variant:"secondary",className:"w-full",type:"button",children:[e.jsx(j,{className:"w-4 h-4 mr-2 rotate-180"}),"Selecionar Imagens"]}),t.length>0&&e.jsx("div",{className:"mt-4 grid grid-cols-2 gap-3",children:t.map((s,r)=>e.jsxs("div",{className:"relative group",children:[e.jsx("img",{src:s.data,alt:s.name,className:"w-full h-24 object-cover rounded-lg border border-border"}),e.jsx("button",{onClick:()=>A(r),className:"absolute top-1 right-1 p-1 bg-red-500 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity",children:e.jsx(P,{className:"w-4 h-4"})}),e.jsx("p",{className:"text-xs text-muted mt-1 truncate",children:s.name})]},r))})]}),e.jsx(y,{id:"page-description",label:"Descreva a Página Desejada *",value:c,onChange:s=>N(s.target.value),rows:5,placeholder:"Ex: Landing page moderna para produto SaaS, com hero section, 3 benefícios principais, depoimentos e CTA destacado. Cores vibrantes azul e roxo."}),e.jsxs(d,{onClick:R,isLoading:T,disabled:!c.trim(),variant:"primary",className:"w-full",children:[e.jsx(v,{className:"w-5 h-5 mr-2"}),"Gerar Código HTML Profissional"]})]})]}),o&&e.jsxs("div",{className:"bg-surface p-6 rounded-xl border border-border",children:[e.jsx("h3",{className:"text-lg font-semibold text-title mb-4",children:"Código Gerado"}),e.jsx("div",{className:"bg-gray-900 p-4 rounded-lg overflow-x-auto max-h-96",children:e.jsx("pre",{className:"text-xs text-green-400 font-mono",children:o})}),e.jsxs("div",{className:"flex gap-3 mt-4",children:[e.jsx(d,{onClick:$,variant:"secondary",size:"sm",className:"flex-1",children:"Copiar Código"}),e.jsxs(d,{onClick:E,variant:"primary",size:"sm",className:"flex-1",children:[e.jsx(j,{className:"w-4 h-4 mr-2"}),"Baixar .html"]}),e.jsxs(d,{onClick:L,variant:"ghost",size:"sm",className:"flex-1",children:[e.jsx(D,{className:"w-4 h-4 mr-2"}),"Enviar"]}),e.jsxs(d,{onClick:()=>b(!m),variant:"ghost",size:"sm",children:[e.jsx(q,{className:"w-4 h-4 mr-2"}),m?"Ocultar":"Ver"," Preview"]})]})]})]}),e.jsxs("div",{className:"bg-surface rounded-xl border border-border overflow-hidden",children:[e.jsxs("div",{className:"bg-gray-100 dark:bg-gray-900 px-4 py-3 border-b border-border flex items-center justify-between",children:[e.jsx("h3",{className:"text-sm font-bold text-title uppercase tracking-wide",children:"Preview ao Vivo"}),m&&e.jsxs("span",{className:"text-xs text-green-500 font-semibold flex items-center gap-1",children:[e.jsx("span",{className:"w-2 h-2 bg-green-500 rounded-full animate-pulse"}),"Ativo"]})]}),m&&o?e.jsx("iframe",{srcDoc:o,className:"w-full h-[600px] bg-white",title:"HTML Preview",sandbox:"allow-scripts"}):e.jsxs("div",{className:"flex flex-col items-center justify-center h-[600px] text-muted",children:[e.jsx(f,{className:"w-16 h-16 mb-4 opacity-20"}),e.jsx("p",{className:"text-sm",children:"Preview aparecerá aqui após gerar o código"})]})]})]}),e.jsx("div",{className:"p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800",children:e.jsxs("p",{className:"text-sm text-muted",children:[e.jsx("strong",{children:"💡 Dica:"})," Quanto mais detalhada a descrição da página, melhor será o código gerado. Especifique cores, layout, seções e estilo desejado."]})})]})};export{K as default};
